window.addEventListener('load', function(){
    const sections = this.document.querySelectorAll('.section, .header');

    sections.forEach((section, index) => {
        this.setTimeout(() => {
            section.style.opacity= '1';
            section.style.transform = 'translateY(0)';
        },  index * 150);
    });
 });